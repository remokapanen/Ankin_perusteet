from .browser import setup_browser
from .deck_browser import setup_deck_browser

setup_deck_browser()
setup_browser()
