**auto_sync**

options:

- `"on_ankiweb_sync"`

- `"on_startup"`

    Requires to be logged into AnkiWeb.

-  `"never"`

**suspend_new_cards_of_existing_notes**

options:

- `"if_siblings_are_suspended"`

- `"never"`

- `"always"`

**use_staging**

Connect to the AnkiHub staging server instead of production. Used for testing the add-on.
